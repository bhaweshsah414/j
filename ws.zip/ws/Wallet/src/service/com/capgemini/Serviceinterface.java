package service.com.capgemini;
import java.math.BigDecimal;
import bean.com.capgemini.Customer;

public interface Serviceinterface {
	public Customer CreateAccount(String name, String mobile, BigDecimal amount);
	public Customer showbalance(String mobile);

}
