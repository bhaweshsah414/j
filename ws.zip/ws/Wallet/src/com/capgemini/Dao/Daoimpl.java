package com.capgemini.Dao;

import java.math.BigDecimal;
import java.util.*; 

import bean.com.capgemini.Customer;

public class Daoimpl{
Customer customer= new Customer();
 HashMap<String,Customer> map = new HashMap<String, Customer>();
	
	public Customer CreateAccount(Customer cust) {
		
		map.put(customer.getMobile(),customer);
		
		
		
		
		return customer;

		
	}
	
	public Customer Showbalance(String mobile) {
		
		
		customer= map.get(mobile);
		return customer;
	}

}
